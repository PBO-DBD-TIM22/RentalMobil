/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koneksi.program;

import java.sql.SQLException;
/**
 *
 * @author nurul
 */
public class Peminjam extends Database {
    public int NIK;
    public String Nama;
    public String Alamat;
    public String No_Telp;  
    public String NIK_User;
    
    public int getNIK(){
        return NIK;
    }
    
    public String getNIK_User(){
        return NIK_User;
    }
    
    public void setNIK(int NIK){
        this.NIK = NIK;
    }
    
    public String getNama(){
        return Nama;
    }
    
    public void setNama(String Nama){
        this.Nama = Nama;  
    }
    
    public String getAlamat(){
        return Alamat;
    } 
    
    public void setAlamat(String Alamat){
        this.Alamat = Alamat;  
    } 
    
    public String getNoTelp(){
        return No_Telp;
    } 
    
    public void setNoTelp(String No_Telp){
        this.No_Telp = No_Telp;  
    } 
    
    
    public boolean findPeminjam(String NIK, String Nama, String Alamat, String No_Telp) {
        boolean operasiSukses = false;
        
        try{
            this.openConnection();
            
            String sql = "SELECT * FROM peminjam";
            
            this.preparedStatement = this.connection.prepareStatement(sql);
            
            this.preparedStatement.setInt(1, this.NIK);
            this.preparedStatement.setString(2, this.Nama);
            this.preparedStatement.setString(3, this.Alamat);
            this.preparedStatement.setString(4, this.No_Telp);
            
            
            int rowsAffected = this.preparedStatement.executeUpdate(); // Menggunakan executeUpdate

        if (rowsAffected > 0) {
            operasiSukses = true;
        }
            
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            this.closeConnection();
            
        }return operasiSukses;
    }
    
    public boolean createPeminjam(){
        boolean operasiSukses = false;
        
        try{
            this.openConnection();
            
            String sql = "INSERT INTO peminjam VALUES (?,?,?,?,?)";
            this.preparedStatement = this.connection.prepareStatement(sql);
            
            this.preparedStatement.setInt(1, this.NIK);
            this.preparedStatement.setString(2, this.Nama);
            this.preparedStatement.setString(3, this.Alamat);
            this.preparedStatement.setString(4, this.No_Telp);
            this.preparedStatement.setString(5, this.NIK_User);
            int rowsAffected = this.preparedStatement.executeUpdate(); // Menggunakan executeUpdate

        if (rowsAffected > 0) {
            operasiSukses = true;
        }
            
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            this.closeConnection();
            
        }return operasiSukses;
    }
    
    public boolean updatePeminjam(String NIK, String Nama, String Alamat, String No_Telp){
        boolean operasiSukses = false;
        
        try{
            this.openConnection();
            
            String sql = "UPDATE peminjam SET NIK = ?, Nama = ?, Alamat = ?, No_Telp = ? WHERE NIK = ?";
            
            this.preparedStatement = this.connection.prepareStatement(sql);
            
            this.preparedStatement.setInt(1, this.NIK);
            this.preparedStatement.setString(2, this.Nama);
            this.preparedStatement.setString(3, this.Alamat);
            this.preparedStatement.setString(4, this.No_Telp);
            
            
            int rowsAffected = this.preparedStatement.executeUpdate(); // Menggunakan executeUpdate

        if (rowsAffected > 0) {
            operasiSukses = true;
        }
            
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            this.closeConnection();
            
        }return operasiSukses;
            
    }
    
    public boolean deletePeminjam(String NIK){
        boolean operasiSukses = false;
        
        try {
            this.openConnection();
            
            String sql = "DELETE FROM peminjam WHERE NIK = ?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            
            this.preparedStatement.setInt(1, this.NIK);
            
            
            int rowsAffected = this.preparedStatement.executeUpdate(); // Menggunakan executeUpdate

        if (rowsAffected > 0) {
            operasiSukses = true;
        }
            
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            this.closeConnection();
            
        }return operasiSukses;
            
            
        } 
    
}
