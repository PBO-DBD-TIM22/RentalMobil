/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koneksi.program;
import java.sql.SQLException;

/**
 *
 * @author nurul
 */
public class Owner extends User {
    public String NIK;
    public String Nama;
    public String Username;
    public String Password;
    public String Role;
    public String No_Telp;
    
    @Override
    public String getNIK(){
        return NIK;
    }

    @Override
    public String getNama(){
        return Nama;
    }
    
    @Override
    public String getusername(){
        return Username = Username;
    }

    @Override
    public String getPassword(){
        return Password;
    }
    
    @Override
    public void setPassword(String password){
        this.Password = Password;
    }
    
    @Override
    public String getRole(){
        return Role;
    }
    
    @Override
    public void setRole (String Role){
        this.Role = Role;
    }    
    
    @Override
    public boolean userOwner(){
        boolean operasiSukses = false;
        
        try{
            openConnection();
            
            String sql = "SELECT u.*, o.No_Telepon FROM user u JOIN owner o ON u.NIK = o.NIK WHERE u.Username = ? AND u.Password = ? AND u.Role = ? AND o.NIK = ?";
            
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, Username);
            
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                this.NIK = resultSet.getString("NIK");
                this.Nama = resultSet.getString("Nama");
                this.Username = resultSet.getString("Username");
                this.Password = resultSet.getString("Password");
                this.Role = resultSet.getString("Role");
                this.No_Telp = resultSet.getString("No_Telepon");
                
                operasiSukses = true;
                        
            }
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            closeConnection();
            
        }return operasiSukses;
    } 

    
    @Override
    public boolean createUser() {
        boolean operasiSukses = false;

        try {
            openConnection();

            String sql = "INSERT INTO owner (NIK, Nama, Username, Password, Role, No_Telepon) VALUES (?, ?, ?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, NIK);
            preparedStatement.setString(2, Nama);
            preparedStatement.setString(3, Username);
            preparedStatement.setString(4, Password);
            preparedStatement.setString(5, Role); // Pastikan Role juga dimasukkan ke dalam tabel owner jika dibutuhkan
            preparedStatement.setString(6, No_Telp);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                operasiSukses = true;
            }
        } catch (SQLException e) {
            displayErrors(e);
        } finally {
            closeConnection();
        }

        return operasiSukses;
    }

    @Override
    public boolean editUser() {
        boolean operasiSukses = false;

        try {
            openConnection();

            String sql = "UPDATE owner SET Nama = ?, Username = ?, Password = ?, No_Telepon = ? WHERE NIK = ?";
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, Nama);
            preparedStatement.setString(2, Username);
            preparedStatement.setString(3, Password);
            preparedStatement.setString(4, No_Telp);
            preparedStatement.setString(5, NIK);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                operasiSukses = true;
            }
        } catch (SQLException e) {
            displayErrors(e);
        } finally {
            closeConnection();
        }

        return operasiSukses;
    }
    
  
    @Override
    public boolean deleteUser() {
        boolean operasiSukses = false;

        try {
            openConnection();

            String sql = "DELETE FROM owner WHERE NIK = ?";
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, NIK);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                operasiSukses = true;
            }
        } catch (SQLException e) {
            displayErrors(e);
        } finally {
            closeConnection();
        }

        return operasiSukses;
    }


    
}
