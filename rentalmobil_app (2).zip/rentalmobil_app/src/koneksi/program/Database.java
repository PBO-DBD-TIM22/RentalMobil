/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koneksi.program;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.ResultSetMetaData;

/**
 *
 * @author nurul
 */

public class Database {
    public Connection connection = null;    
    public Statement statement;
    public PreparedStatement preparedStatement;
    public ResultSet resultSet;
    private String query;
    private static Connection MySQLConfig;

    public final void openConnection() {
        try{
            final String url = "jdbc:mysql://localhost:3306/rentalmobil_app?user=root&password=";

            this.connection = DriverManager.getConnection(url);
        } catch (SQLException e){
            this.displayErrors(e);
        }
    }
    

    public static Connection configDB()throws SQLException{
        try{
            String url = "jdbc:mysql://localhost:3306/rentalmobil_app";
            String user = "root";
            String pass = "";
            
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            MySQLConfig = DriverManager.getConnection(url, user, pass);
            
        }catch(SQLException e){
            System.out.println("Koneksi ke Database Gagal " + e.getMessage());
        }
        
        return MySQLConfig;
    }

    public final void closeConnection() {
        try {
            if (this.resultSet != null) this.resultSet.close();
            if (this.statement != null) this.statement.close();
            if (this.preparedStatement != null) this.preparedStatement.close();
            if (this.connection != null) this.connection.close();
            
            this.resultSet = null;
            this.statement = null;
            this.preparedStatement = null;
            this.connection = null;
        } catch (SQLException e) {
            this.displayErrors(e);
        }
    }
    
    public final ArrayList<ArrayList> all(String query) {
            ArrayList<ArrayList> rows = new ArrayList();
            
            try{
                this.statement = this.connection.createStatement();
                this.resultSet = this.statement.executeQuery(query);
                
                while (this.resultSet.next()) {
                    ResultSetMetaData rsMetaData = this.resultSet.getMetaData();
                    int columnCount = rsMetaData.getColumnCount();
                    
                    ArrayList<String> columns = new ArrayList();
                    
                    for (int i = 1; i <= columnCount; i++) {
                        columns.add(this.resultSet.getString(i));
                    }
                    rows.add(columns);
                }
            } catch (SQLException e){
                this.displayErrors(e);
            }
            return rows;
    }
    
    
    
    public final void displayErrors(SQLException e) {
        System.out.println("SQLException: " + e.getMessage());
        System.out.println("SQLState: " + e.getSQLState());
        System.out.println("VendorError: " + e.getErrorCode());
    }

    public PreparedStatement prepareStatement(String sql) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}