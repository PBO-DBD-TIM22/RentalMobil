/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koneksi.program;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author nurul
 */
public class Transaksi extends Database{
    public int NoTransaksi;
    public Date Tgl_Peminjaman;
    public Date Tgl_Pengembalian;
    public String Durasi;
    public int Total;
    public String ID_Mobil;
    public int NIK;
    
    public int getNoTransaksi(){
        return NoTransaksi;
    }
    
    public void setNoTransaksi(int NoTransaksi){
        this.NoTransaksi = NoTransaksi;
    }
    
    public Date getTglPeminjaman(){
        return Tgl_Peminjaman;
    }
    
    public void setTglPeminjaman(Date Tgl_Peminjaman){
        this.Tgl_Peminjaman = Tgl_Peminjaman;
    }  
    
    public Date getTglPengembalian(){
        return Tgl_Pengembalian;
    }
    
    public void setTglPengembalian(Date Tgl_Pengembalian){
        this.Tgl_Pengembalian = Tgl_Pengembalian;
    }     

    public String getDurasi(){
        return Durasi;
    }
    
    public void setDurasi(String Durasi){
        this.Durasi = Durasi;
    } 

    public int getTotal(){
        return Total;
    }
    
    public void setTotal(int Total){
        this.Total = Total;
    }
    
    public void setIDMobil(String ID_Mobil){
        this.ID_Mobil = ID_Mobil;
    }
    
    public void setNIK(int NIK){
        this.NIK = NIK;
    }
    
    public boolean findPeminjam() {
        boolean operasiSukses = false;

        try {
            this.openConnection();

                String sql = "SELECT * FROM transaksimobil WHERE NoTransaksi = ? AND Tgl_Peminjaman = ? AND Tgl_Pengembalian = ? AND Durasi = ? AND Total = ? AND ID_Mobil = ? AND NIK = ?";

                this.preparedStatement = this.connection.prepareStatement(sql);

                this.preparedStatement.setInt(1, this.NoTransaksi);
                this.preparedStatement.setDate(2, this.Tgl_Peminjaman);
                this.preparedStatement.setDate(3, this.Tgl_Pengembalian);
                this.preparedStatement.setString(4, this.Durasi);
                this.preparedStatement.setInt(5, this.Total);
                this.preparedStatement.setString(6, this.ID_Mobil);
                this.preparedStatement.setInt(7, this.NIK);

                operasiSukses = this.preparedStatement.execute(); // Menggunakan execute

                // Cek apakah ada hasil yang ditemukan dalam resultSet
                if (operasiSukses) {
                    resultSet = preparedStatement.getResultSet();
                }

            } catch (SQLException e) {
                this.displayErrors(e);

            } finally {
                this.closeConnection();
            }

            return operasiSukses;

    }
    
    public boolean tampilMobil() {
        boolean operasiSukses = false;
        
        try {
            this.openConnection();
            
            String sql = "SELECT Merek, Tahun_Produksi, Nomor_Polisi, Harga_Sewa, Status FROM mobil WHERE ID_Mobil = ?";
            
            this.preparedStatement.setString(1, this.ID_Mobil);
            
            operasiSukses = this.preparedStatement.execute(); // Menggunakan execute
            
            operasiSukses = true;
            
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            this.closeConnection();
            
        }return operasiSukses;
        
    }
    
    public boolean createTransaksi(){
        boolean operasiSukses = false;
        
        try{
            this.openConnection();
            
            String sql = "INSERT INTO transaksimobil VALUES (?,?,?,?,?,?,?)";
            this.preparedStatement = this.connection.prepareStatement(sql);
            
            this.preparedStatement.setDate(1, this.Tgl_Peminjaman);
            this.preparedStatement.setDate(2, this.Tgl_Pengembalian);
            this.preparedStatement.setString(3, this.Durasi);
            this.preparedStatement.setInt(4, this.Total);
            this.preparedStatement.setString(5, this.ID_Mobil);
            this.preparedStatement.setInt(6, this.NIK);

            
            int rowsAffected = this.preparedStatement.executeUpdate(); // Menggunakan executeUpdate

            if (rowsAffected > 0) {
                operasiSukses = true;
            }
            
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            this.closeConnection();
            
        }return operasiSukses;
    }   


    public boolean isMobilTidakTersedia(String idMobil) {
        boolean hasil = false;
        String status = "";

        String sql = "SELECT Status FROM mobil WHERE ID_Mobil = ?";
        try {
            this.openConnection();
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setString(1, idMobil);
            ResultSet rs = this.preparedStatement.executeQuery();

            while (rs.next()) {
                status = rs.getString("Status");
            }

            hasil = !status.equals("Tidak Tersedia");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat memeriksa status mobil: " + e.getMessage(), "Kesalahan Database", JOptionPane.ERROR_MESSAGE);
        } finally {
            this.closeConnection();
        }
        return hasil;
    } 
    
    public boolean isMobilAvailable(String idMobil) {
        boolean available = false;
        String status = "";

        try {
            this.openConnection(); // Buka koneksi database

            // Query SQL untuk mendapatkan status mobil berdasarkan ID
            String sql = "SELECT Status FROM mobil WHERE ID_Mobil = ?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setString(1, idMobil);

            ResultSet resultSet = this.preparedStatement.executeQuery();

            if (resultSet.next()) {
                status = resultSet.getString("Status");

                // Jika status adalah "Tersedia", mobil tersedia
                available = status.equals("Tersedia");
            }
        } catch (SQLException e) {
            // Tangani kesalahan SQL
            e.printStackTrace();
        } finally {
            this.closeConnection(); // Tutup koneksi database
        }

        return available;
    }

    
    public boolean cekstatus(String nopolValue) throws SQLException {
        String status1 = "";
        boolean success = false;

        // Memeriksa status mobil
        String selectSql = "SELECT Status FROM mobil WHERE ID_Mobil = ?";
        try {
            this.openConnection(); // Buka koneksi database
            this.preparedStatement = this.connection.prepareStatement(selectSql);
            this.preparedStatement.setString(1, nopolValue);
            ResultSet rs = this.preparedStatement.executeQuery();

            while (rs.next()) {
                status1 = rs.getString("Status");
            }

            if (!status1.equals("Tidak Tersedia")) {
                // Mengubah status mobil menjadi "Tidak Tersedia"
                String updateSql = "UPDATE mobil SET Status = 'Tidak Tersedia' WHERE ID_Mobil = ?";
                this.preparedStatement = this.connection.prepareStatement(updateSql);
                this.preparedStatement.setString(1, nopolValue);
                int rowsAffected = this.preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Status mobil berhasil diubah menjadi 'Tidak Tersedia'");
                    success = true;
                }
            } else {
                success = true; // Status sudah "Tidak Tersedia", dianggap sukses
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat memeriksa dan mengubah status mobil: " + e.getMessage(), "Kesalahan Database", JOptionPane.ERROR_MESSAGE);
        } finally {
            this.closeConnection(); // Tutup koneksi database
        }

        return success;
    }
    
    public ArrayList<String> loadMobil() {
        ArrayList<String> mobilList = new ArrayList<>();
        try {
            this.openConnection(); // Buka koneksi database
            String sql = "SELECT * FROM mobil";
            this.preparedStatement = this.connection.prepareStatement(sql);
            ResultSet res = this.preparedStatement.executeQuery();

            while (res.next()) {
                mobilList.add(res.getString("ID_Mobil"));
            }
        } catch (SQLException ex) {
            // Menggantinya dengan menampilkan pesan kesalahan menggunakan JOptionPane
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan dalam pengambilan data: " + ex.getMessage(), "Kesalahan Database", JOptionPane.ERROR_MESSAGE);

        } finally {
            this.closeConnection(); // Tutup koneksi database
        }

        return mobilList;
    }

}
