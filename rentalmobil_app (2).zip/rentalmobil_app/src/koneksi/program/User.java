/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koneksi.program;
import java.sql.SQLException;
/**
 *
 * @author nurul
 */
public class User extends Database{
    public String NIK;
    public String Nama;
    public String Username;
    public String Password;
    public String Role;
    public String Gaji;
    public String JamKerja;

//    public User_akun(){
//        this.Username = Username;
//        this.Password = Password;
//        this.Role = Role;
//    }
    
    public String getNIK(){
        return NIK;
    }

    public String getNama(){
        return Nama;
    }
    
    public String getGaji(){
        return Gaji;
    }
    
    public String getJamKerja(){
        return JamKerja;
    }
    
    public String getusername(){
        return Username = Username;
    }

    public String getPassword(){
        return Password;
    }
    
    public void setPassword(String password){
        this.Password = Password;
    }
    
    public String getRole(){
        return Role;
    }
    
    public void setRole (String Role){
        this.Role = Role;
    }     
    
    
    public boolean login(String username, String password, String role) {
    boolean operasiSukses = false;

    try {
        this.openConnection();

        String sql = "SELECT * FROM user WHERE Username=? AND Password=? AND Role=?";

        preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1, username);
        preparedStatement.setString(2, password);
        preparedStatement.setString(3, role);

        resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            operasiSukses = true;
        }
    } catch (SQLException e) {
        this.displayErrors(e);
        
    } finally {
        closeConnection();
    }
    return operasiSukses;
}

    
    public boolean userOwner(){
        boolean operasiSukses = false;
        
        try{
            openConnection();
            
            String sql = "SELECT u.*, o.No_Telepon FROM user u JOIN owner o ON u.NIK = o.NIK WHERE u.Username = ? AND u.Password = ? AND u.Role = ? AND o.NIK = ?";
            
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, Username);
            
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                this.NIK = resultSet.getString("NIK");
                this.Nama = resultSet.getString("Nama");
                this.Username = resultSet.getString("Username");
                this.Password = resultSet.getString("Password");
                this.Role = resultSet.getString("Role");
                
                operasiSukses = true;
                        
            }
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            closeConnection();
            
        }return operasiSukses;
    }
    
    public boolean userStaff(String Username){
        boolean operasiSukses = false;
        
        try{
            openConnection();
            
            String sql = "SELECT u.*, s.Gaji, s.Jam_Kerja FROM user u JOIN staff s ON u.NIK = s.NIK WHERE u.Username = ? AND u.Password = ? AND u.Role = ? AND s.NIK = ?";
            
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(2, Username);
            
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                this.NIK = resultSet.getString("NIK");
                this.Nama = resultSet.getString("Nama");
                this.Username = resultSet.getString("Username");
                this.Password = resultSet.getString("Password");
                this.Role = resultSet.getString("Role");
                
                operasiSukses = true;
                        
            }
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            closeConnection();
            
        }return operasiSukses;
        }
    
    public boolean createUser() {
        boolean operasiSukses = false;
        
        try{
            this.openConnection();
            
            String sql = "INSERT INTO user VALUES (?, ?, ?, ?, ?)";
            this.preparedStatement = this.connection.prepareStatement(sql);
            
            this.preparedStatement.setString(1, this.NIK);
            this.preparedStatement.setString(2, this.Nama);
            this.preparedStatement.setString(3, this.Username);
            this.preparedStatement.setString(4, this.Password);
            this.preparedStatement.setString(5, this.Role);
            
            int rowsAffected = this.preparedStatement.executeUpdate(); // Menggunakan executeUpdate

        if (rowsAffected > 0) {
            operasiSukses = true;
        }
            
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            this.closeConnection();
            
        }return operasiSukses;
    }
    
    public boolean editUser() {
        boolean operasiSukses = false;
        
        try{
            this.openConnection();
            
            String sql = "UPDATE user SET NIK = ?, Nama = ?, Username = ?, Password = ?, Role = ? WHERE NIK = ?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            
            this.preparedStatement.setString(1, this.NIK);
            this.preparedStatement.setString(2, this.Nama);
            this.preparedStatement.setString(3, this.Username);
            this.preparedStatement.setString(4, this.Password);
            this.preparedStatement.setString(5, this.Role);
            this.preparedStatement.setString(6, this.NIK);
            
            int rowsAffected = this.preparedStatement.executeUpdate(); // Menggunakan executeUpdate

        if (rowsAffected > 0) {
            operasiSukses = true;
        }
            
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            this.closeConnection();
            
        }return operasiSukses;
                    
    }
    
    public boolean deleteUser(){
        boolean operasiSukses = false;
        
        try {
            this.openConnection();
            
            String sql = "DELETE FROM user WHERE NIK = ?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            
            this.preparedStatement.setString(1, this.NIK);
            
            int rowsAffected = this.preparedStatement.executeUpdate(); // Menggunakan executeUpdate

        if (rowsAffected > 0) {
            operasiSukses = true;
        }
            
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            this.closeConnection();
            
        }return operasiSukses;
            
            
        } 
    
    
}
