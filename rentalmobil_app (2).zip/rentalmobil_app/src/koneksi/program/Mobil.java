/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koneksi.program;

import java.sql.SQLException;
/**
 *
 * @author nurul
 */

public class Mobil extends Database {
    
    public String ID_Mobil;
    public String Merek;
    public String Tahun_Produksi;
    public String Nomor_Polisi;
    public int Harga_Sewa;
    public String Status;
    public String NIK;
    
    public String getIDMobil(){
        return ID_Mobil;
    }
    
    public void setIDMobil(String ID_Mobil){
        this.ID_Mobil = ID_Mobil;
    }
    
    public String getMerek(){
        return Merek;
    }
    
    public void setMerek(String Merek){
        this.Merek = Merek;
    }
 
    public String getTahun(){
        return Tahun_Produksi;
    }    
    
    public void setTahun(String Tahun_Produksi){
        this.Tahun_Produksi = Tahun_Produksi;
    }
 
    public String getNopol(){
        return Nomor_Polisi;
    }    
    
    public void setNopol(String Nomor_Polisi){
        this.Nomor_Polisi = Nomor_Polisi;
    }
    
    public int getHarga(){
        return Harga_Sewa;
    }

    public void setHarga(int Harga_Sewa){
        this.Harga_Sewa = Harga_Sewa;
    }
    
    public String getStatus(){
        return Status;
    }
    
    public void setStatus(String Status){
        this.Status = Status;
    }
    
    public String getNIK(){
        return NIK;
    }
    
        public boolean findMobil(String ID_Mobil, String Merek, String Tahun_Produksi, String Nomor_Polisi, int Harga_Sewa, String Status) {
        boolean operasiSukses = false;
        
        try{
            this.openConnection();
            
            String sql = "SELECT * FROM mobil WHERE ID_Mobil = ? AND Merek = ? AND Tahun_Produksi = ? AND Nomor_Polisi = ? AND Harga_Sewa = ? AND Status = ?";
            
            this.preparedStatement = this.connection.prepareStatement(sql);
            
            this.preparedStatement.setString(1, this.ID_Mobil);
            this.preparedStatement.setString(2, this.Merek);
            this.preparedStatement.setString(3, this.Tahun_Produksi);
            this.preparedStatement.setString(4, this.Nomor_Polisi);
            this.preparedStatement.setInt(5, this.Harga_Sewa);
            this.preparedStatement.setString(6, this.Status);
            
            resultSet = preparedStatement.executeQuery();
            
            operasiSukses = true;
            
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            this.closeConnection();
            
        }return operasiSukses;
    }


    public boolean createMobil() {
        boolean operasiSukses = false;
        
        try{
            this.openConnection();
            
            String sql = "INSERT INTO mobil VALUES (?,?,?,?,?,?,?)";
            this.preparedStatement = this.connection.prepareStatement(sql);
            
            this.preparedStatement.setString(1, this.ID_Mobil);
            this.preparedStatement.setString(2, this.Merek);
            this.preparedStatement.setString(3, this.Tahun_Produksi);
            this.preparedStatement.setString(4, this.Nomor_Polisi);
            this.preparedStatement.setInt(5, this.Harga_Sewa);
            this.preparedStatement.setString(6, this.Status);
            this.preparedStatement.setString(7, this.NIK);
            
            int rowsAffected = this.preparedStatement.executeUpdate(); // Menggunakan executeUpdate

        if (rowsAffected > 0) {
            operasiSukses = true;
        }
            
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            this.closeConnection();
            
        }return operasiSukses;
    }
    
    public boolean updateMobil(){
        boolean operasiSukses = false;
        
        try{
            this.openConnection();
            
            String sql = "UPDATE mobil SET ID_Mobil = ?, Merek = ?, Tahun_Produksi = ?, Nomor_Polisi = ?, Harga_Sewa = ?, Status = ? WHERE ID_Mobil = ?";
            
            this.preparedStatement = this.connection.prepareStatement(sql);
            
            this.preparedStatement.setString(1, this.ID_Mobil);
            this.preparedStatement.setString(2, this.Merek);
            this.preparedStatement.setString(3, this.Tahun_Produksi);
            this.preparedStatement.setString(4, this.Nomor_Polisi);
            this.preparedStatement.setInt(5, this.Harga_Sewa);
            this.preparedStatement.setString(6, this.Status);
            this.preparedStatement.setString(7, this.ID_Mobil);
            
            int rowsAffected = this.preparedStatement.executeUpdate(); // Menggunakan executeUpdate

        if (rowsAffected > 0) {
            operasiSukses = true;
        }
            
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            this.closeConnection();
            
        }return operasiSukses;
            
    }
    
    public boolean deleteMobil(){
        boolean operasiSukses = false;
        
        try {
            this.openConnection();
            
            String sql = "DELETE FROM mobil WHERE ID_Mobil = ?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            
            this.preparedStatement.setString(1, this.ID_Mobil);
            
            int rowsAffected = this.preparedStatement.executeUpdate(); // Menggunakan executeUpdate

        if (rowsAffected > 0) {
            operasiSukses = true;
        }
            
        } catch (SQLException e){
            this.displayErrors(e);
            
        }finally{
            this.closeConnection();
            
        }return operasiSukses;
            
            
        }   
    
}

