/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package menu.rental;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import koneksi.program.Database;
import koneksi.program.*;
import java.util.ArrayList;



/**
 *
 * @author nurul
 */
public class Menu_Owner extends javax.swing.JFrame {

    private Object status1;

    /**
     * Creates new form Bar
     * @param ID_Mobil
     * @param NIK
     * @param ID_Peminjam
     */
    public Menu_Owner(String ID_Mobil, String NIK, String ID_Peminjam) {
        initComponents();
    }
    
    private void display_user() {
        Database konek = new Database();
        
        konek.openConnection();
        
        ArrayList<ArrayList> user = konek.all("SELECT * FROM user");
       
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("NIK");
        model.addColumn("Nama");
        model.addColumn("Username");
        model.addColumn("Password");
        model.addColumn("Role");
        
        for (ArrayList<String> rowData : user) {
            model.addRow(rowData.toArray());
        }
        
        konek.closeConnection();
        tabelPegawai.setModel(model);
    }
    
    private void display_peminjaman() {
        Database konek = new Database();
        
        konek.openConnection();
        
        ArrayList<ArrayList> peminjam = konek.all("SELECT Tgl_Peminjaman, Tgl_Pengembalian, Durasi, Total, Mobil_ID_Mobil, Peminjam_NIK FROM transaksimobil");
       
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Tgl Peminjaman");
        model.addColumn("Tgl Pengembalian");
        model.addColumn("Durasi");
        model.addColumn("Total");
        model.addColumn("ID Mobil");
        model.addColumn("NIK Peminjam");
        
        for (ArrayList<String> rowData : peminjam) {
            model.addRow(rowData.toArray());
        }
        
        konek.closeConnection();
        tabel_peminjaman.setModel(model);
    
    }
    

    private void display_peminjam(){
        Database konek = new Database();
        
        konek.openConnection();
        
        ArrayList<ArrayList> mobil = konek.all("SELECT * FROM peminjam");
       
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("NIK");
        model.addColumn("Nama");
        model.addColumn("Alamat");
        model.addColumn("No Telepon");
        
        for (ArrayList<String> rowData : mobil) {
            model.addRow(rowData.toArray());
        }
        
        konek.closeConnection();
        tabel_peminjam.setModel(model);
    }  
    
    private void display_peminjam2(){
        Database konek = new Database();
        
        konek.openConnection();
        
        ArrayList<ArrayList> peminjam = konek.all("SELECT * FROM peminjam");
       
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("NIK");
        model.addColumn("Nama");
        model.addColumn("Alamat");
        model.addColumn("No Telepon");
        
        for (ArrayList<String> rowData : peminjam) {
            model.addRow(rowData.toArray());
        }
        
        konek.closeConnection();
        tabel_peminjam1.setModel(model);
    } 
    
    
    private void display_mobil() {
        Database konek = new Database();
        
        konek.openConnection();
        
        ArrayList<ArrayList> mobil = konek.all("SELECT * FROM mobil");
       
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID Mobil");
        model.addColumn("Merek");
        model.addColumn("Tahun Produksi");
        model.addColumn("No Polisi");
        model.addColumn("Harga Sewa");
        model.addColumn("Status");
        
        for (ArrayList<String> rowData : mobil) {
            model.addRow(rowData.toArray());
        }
        
        konek.closeConnection();
        tabelMobil.setModel(model);
    }
    
    private void clear_user(){
        txtNIK.setEditable(true);
        txtNIK.setText(null);
        txtNama.setText(null);
        txtUser.setText(null);
        txtPass.setText(null);
        cbRole.setSelectedItem(this);
    }
    
    private void clear_mobil(){
        txtIDMobil.setEditable(true);
        txtIDMobil.setText(null);
        txtMerek.setText(null);
        txtYear.setText(null);
        txtNoPol.setText(null);
        txtHarga.setText(null);
        cbStatus.setSelectedItem(this);

    }
    
    private void clear_peminjam(){
        txtNIK1.setEditable(true);
        txtNIK1.setText(null);
        txtNama1.setText(null);
        txtAlamat.setText(null);
        txtTelp.setText(null);
    }

    public Menu_Owner(){
        initComponents();
        display_mobil();
        display_peminjam();
        display_peminjam2();
        display_user();
        display_peminjaman();
        clear_mobil();
        clear_user();
        clear_peminjam();
        
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        kGradientPanel1 = new keeptoo.KGradientPanel();
        tbAddStaff = new usu.widget.ButtonGlass();
        tbAddMobil = new usu.widget.ButtonGlass();
        tbAddPeminjam = new usu.widget.ButtonGlass();
        tbDataPeminjam = new usu.widget.ButtonGlass();
        tbDataPeminjaman = new usu.widget.ButtonGlass();
        jLabel58 = new javax.swing.JLabel();
        btn_logout = new usu.widget.ButtonGlass();
        jPanel2 = new javax.swing.JPanel();
        Dashboard = new keeptoo.KGradientPanel();
        jLabel54 = new javax.swing.JLabel();
        Pegawai = new keeptoo.KGradientPanel();
        panelGlass2 = new usu.widget.glass.PanelGlass();
        jLabel3 = new javax.swing.JLabel();
        txtNIK = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        txtNama = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        cbRole = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        txtUser = new javax.swing.JTextField();
        txtPass = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();
        btn_edit1 = new usu.widget.ButtonGlass();
        btn_delete1 = new usu.widget.ButtonGlass();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabelPegawai = new javax.swing.JTable();
        panelGlass7 = new usu.widget.glass.PanelGlass();
        txt_cari = new javax.swing.JTextField();
        btn_cari1 = new usu.widget.ButtonGlass();
        btn_add1 = new usu.widget.ButtonGlass();
        btn_refresh = new usu.widget.ButtonGlass();
        Form_Peminjam = new keeptoo.KGradientPanel();
        btnnext = new usu.widget.ButtonGlass();
        jLabel7 = new javax.swing.JLabel();
        panelGlass3 = new usu.widget.glass.PanelGlass();
        jLabel8 = new javax.swing.JLabel();
        txtNama1 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        txtNIK1 = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        txtAlamat = new javax.swing.JTextField();
        txtTelp = new javax.swing.JTextField();
        tbadd_peminjam = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        tabel_peminjam1 = new javax.swing.JTable();
        btn_refresh2 = new usu.widget.ButtonGlass();
        Data_Peminjam = new keeptoo.KGradientPanel();
        panelGlass4 = new usu.widget.glass.PanelGlass();
        jLabel23 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        lbl_nik = new javax.swing.JLabel();
        lbl_nama = new javax.swing.JLabel();
        lbl_alamat = new javax.swing.JLabel();
        lbl_no_telp = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabel_peminjam = new javax.swing.JTable();
        panelGlass8 = new usu.widget.glass.PanelGlass();
        txt_caridatapeminjam = new javax.swing.JTextField();
        btn_cari2 = new usu.widget.ButtonGlass();
        Mobil = new keeptoo.KGradientPanel();
        panelGlass1 = new usu.widget.glass.PanelGlass();
        jLabel1 = new javax.swing.JLabel();
        txtIDMobil = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtMerek = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtNoPol = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        cbStatus = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtHarga = new javax.swing.JTextField();
        txtYear = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        btn_add = new usu.widget.ButtonGlass();
        btn_edit = new usu.widget.ButtonGlass();
        btn_delete = new usu.widget.ButtonGlass();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelMobil = new javax.swing.JTable();
        btn_refresh1 = new usu.widget.ButtonGlass();
        Data_Peminjaman = new keeptoo.KGradientPanel();
        panelGlass11 = new usu.widget.glass.PanelGlass();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        panelGlass12 = new usu.widget.glass.PanelGlass();
        txt_caripeminjamanmobil = new javax.swing.JTextField();
        btn_cari3 = new usu.widget.ButtonGlass();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabel_peminjaman = new javax.swing.JTable();
        jLabel57 = new javax.swing.JLabel();
        Form_Transaksi = new keeptoo.KGradientPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tabelTransaksi = new javax.swing.JTable();
        panelGlass5 = new usu.widget.glass.PanelGlass();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        lblMerek = new javax.swing.JLabel();
        lblTahun = new javax.swing.JLabel();
        lblHarga = new javax.swing.JLabel();
        cbmobil = new javax.swing.JComboBox<>();
        jLabel38 = new javax.swing.JLabel();
        lblStatus = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        lblnopol = new javax.swing.JLabel();
        panelGlass6 = new usu.widget.glass.PanelGlass();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        tglPeminjaman = new com.toedter.calendar.JDateChooser();
        tglPengembalian = new com.toedter.calendar.JDateChooser();
        txtdurasi = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        btn_hitung = new usu.widget.ButtonGlass();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        txtTotal = new javax.swing.JLabel();
        panelGlass9 = new usu.widget.glass.PanelGlass();
        lblNama = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        lblnik = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        lblAlamat = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        lblTelp = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        btn_submit = new usu.widget.ButtonGlass();
        jLabel53 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        kGradientPanel1.setkEndColor(new java.awt.Color(0, 102, 204));
        kGradientPanel1.setkStartColor(new java.awt.Color(51, 0, 0));

        tbAddStaff.setForeground(new java.awt.Color(255, 255, 255));
        tbAddStaff.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/user_iconn.png"))); // NOI18N
        tbAddStaff.setText("STAFF");
        tbAddStaff.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        tbAddStaff.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        tbAddStaff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbAddStaffMouseClicked(evt);
            }
        });
        tbAddStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbAddStaffActionPerformed(evt);
            }
        });

        tbAddMobil.setForeground(new java.awt.Color(255, 255, 255));
        tbAddMobil.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/pinjam.png"))); // NOI18N
        tbAddMobil.setText("MOBIL");
        tbAddMobil.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        tbAddMobil.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        tbAddMobil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbAddMobilActionPerformed(evt);
            }
        });

        tbAddPeminjam.setForeground(new java.awt.Color(255, 255, 255));
        tbAddPeminjam.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/plus.png"))); // NOI18N
        tbAddPeminjam.setText("ADD PEMINJAM");
        tbAddPeminjam.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        tbAddPeminjam.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        tbAddPeminjam.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbAddPeminjamMouseClicked(evt);
            }
        });
        tbAddPeminjam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbAddPeminjamActionPerformed(evt);
            }
        });

        tbDataPeminjam.setForeground(new java.awt.Color(255, 255, 255));
        tbDataPeminjam.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/user_friend.png"))); // NOI18N
        tbDataPeminjam.setText("DATA PEMINJAM");
        tbDataPeminjam.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        tbDataPeminjam.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        tbDataPeminjam.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbDataPeminjamMouseClicked(evt);
            }
        });
        tbDataPeminjam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbDataPeminjamActionPerformed(evt);
            }
        });

        tbDataPeminjaman.setForeground(new java.awt.Color(255, 255, 255));
        tbDataPeminjaman.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/hargasewa.png"))); // NOI18N
        tbDataPeminjaman.setText("DATA PEMINJAMAN");
        tbDataPeminjaman.setFont(new java.awt.Font("Yu Gothic UI", 1, 12)); // NOI18N
        tbDataPeminjaman.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        tbDataPeminjaman.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbDataPeminjamanActionPerformed(evt);
            }
        });

        jLabel58.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/logozipcar (1).png"))); // NOI18N

        btn_logout.setForeground(new java.awt.Color(255, 255, 255));
        btn_logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/log_out.png"))); // NOI18N
        btn_logout.setText("LOG OUT");
        btn_logout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btn_logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout kGradientPanel1Layout = new javax.swing.GroupLayout(kGradientPanel1);
        kGradientPanel1.setLayout(kGradientPanel1Layout);
        kGradientPanel1Layout.setHorizontalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabel58))
                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_logout, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tbDataPeminjaman, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tbDataPeminjam, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tbAddPeminjam, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tbAddMobil, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(tbAddStaff, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        kGradientPanel1Layout.setVerticalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel58, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(tbAddStaff, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tbAddMobil, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tbAddPeminjam, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(tbDataPeminjam, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tbDataPeminjaman, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_logout, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setLayout(new java.awt.CardLayout());

        Dashboard.setkEndColor(new java.awt.Color(0, 204, 255));
        Dashboard.setkStartColor(new java.awt.Color(0, 102, 102));
        Dashboard.setkTransparentControls(false);
        Dashboard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel54.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Dashboard.png"))); // NOI18N
        Dashboard.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel2.add(Dashboard, "card5");

        Pegawai.setkEndColor(new java.awt.Color(0, 204, 255));
        Pegawai.setkStartColor(new java.awt.Color(0, 102, 102));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("NIK");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Nama");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Username");

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Password");

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Role");

        cbRole.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Owner", "Staff" }));
        cbRole.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbRoleActionPerformed(evt);
            }
        });

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/user_tambah_icon.png"))); // NOI18N

        javax.swing.GroupLayout panelGlass2Layout = new javax.swing.GroupLayout(panelGlass2);
        panelGlass2.setLayout(panelGlass2Layout);
        panelGlass2Layout.setHorizontalGroup(
            panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelGlass2Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addGroup(panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panelGlass2Layout.createSequentialGroup()
                        .addGroup(panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtUser)
                            .addComponent(txtPass, javax.swing.GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)))
                    .addGroup(panelGlass2Layout.createSequentialGroup()
                        .addGroup(panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNIK, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNama, javax.swing.GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelGlass2Layout.createSequentialGroup()
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cbRole, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(247, Short.MAX_VALUE))
        );
        panelGlass2Layout.setVerticalGroup(
            panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass2Layout.createSequentialGroup()
                .addGroup(panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelGlass2Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelGlass2Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNIK, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelGlass2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(44, Short.MAX_VALUE))
        );

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("DATA USER PEGAWAI RENTAL MOBIL");

        btn_edit1.setForeground(new java.awt.Color(255, 255, 255));
        btn_edit1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/pencil_edit.png"))); // NOI18N
        btn_edit1.setText("Edit");
        btn_edit1.setRoundRect(true);
        btn_edit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_edit1ActionPerformed(evt);
            }
        });

        btn_delete1.setForeground(new java.awt.Color(255, 255, 255));
        btn_delete1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/trash_box.png"))); // NOI18N
        btn_delete1.setText("Delete");
        btn_delete1.setRoundRect(true);
        btn_delete1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_delete1ActionPerformed(evt);
            }
        });

        tabelPegawai.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tabelPegawai.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tabelPegawai.getTableHeader().setReorderingAllowed(false);
        tabelPegawai.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelPegawaiMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabelPegawai);

        txt_cari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_cariKeyReleased(evt);
            }
        });

        btn_cari1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/search_lense.png"))); // NOI18N
        btn_cari1.setRoundRect(true);
        btn_cari1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cari1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelGlass7Layout = new javax.swing.GroupLayout(panelGlass7);
        panelGlass7.setLayout(panelGlass7Layout);
        panelGlass7Layout.setHorizontalGroup(
            panelGlass7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass7Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(txt_cari, javax.swing.GroupLayout.DEFAULT_SIZE, 694, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_cari1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
        );
        panelGlass7Layout.setVerticalGroup(
            panelGlass7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass7Layout.createSequentialGroup()
                .addGroup(panelGlass7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_cari1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelGlass7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(txt_cari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(6, 6, 6))
        );

        btn_add1.setForeground(new java.awt.Color(255, 255, 255));
        btn_add1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/plus.png"))); // NOI18N
        btn_add1.setText("Add");
        btn_add1.setRoundRect(true);
        btn_add1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_add1ActionPerformed(evt);
            }
        });

        btn_refresh.setForeground(new java.awt.Color(255, 255, 255));
        btn_refresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/refresh.png"))); // NOI18N
        btn_refresh.setText("Refresh");
        btn_refresh.setRoundRect(true);
        btn_refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_refreshActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PegawaiLayout = new javax.swing.GroupLayout(Pegawai);
        Pegawai.setLayout(PegawaiLayout);
        PegawaiLayout.setHorizontalGroup(
            PegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PegawaiLayout.createSequentialGroup()
                .addGroup(PegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PegawaiLayout.createSequentialGroup()
                        .addGap(145, 145, 145)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PegawaiLayout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addGroup(PegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 834, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(PegawaiLayout.createSequentialGroup()
                                .addComponent(btn_add1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(38, 38, 38)
                                .addComponent(btn_edit1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(32, 32, 32)
                                .addComponent(btn_delete1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(41, 41, 41)
                                .addComponent(btn_refresh, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(panelGlass7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PegawaiLayout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(panelGlass2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(182, Short.MAX_VALUE))
        );
        PegawaiLayout.setVerticalGroup(
            PegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PegawaiLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel5)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(panelGlass2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(PegawaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_edit1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_add1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_delete1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_refresh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addComponent(panelGlass7, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );

        jPanel2.add(Pegawai, "card3");

        Form_Peminjam.setkEndColor(new java.awt.Color(0, 204, 255));
        Form_Peminjam.setkStartColor(new java.awt.Color(0, 102, 102));

        btnnext.setForeground(new java.awt.Color(255, 255, 255));
        btnnext.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/arrow_right.png"))); // NOI18N
        btnnext.setText("Next");
        btnnext.setRoundRect(true);
        btnnext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnextActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("FORMULIR DATA PEMINJAM");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Nama");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("NIK");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Alamat");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("No Telepon");

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Karta.png"))); // NOI18N

        tbadd_peminjam.setText("Add Peminjam");
        tbadd_peminjam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbadd_peminjamActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelGlass3Layout = new javax.swing.GroupLayout(panelGlass3);
        panelGlass3.setLayout(panelGlass3Layout);
        panelGlass3Layout.setHorizontalGroup(
            panelGlass3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass3Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(panelGlass3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tbadd_peminjam, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelGlass3Layout.createSequentialGroup()
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addGroup(panelGlass3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelGlass3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelGlass3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNama1, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(panelGlass3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtAlamat, javax.swing.GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
                                .addComponent(txtTelp))
                            .addComponent(txtNIK1, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(94, Short.MAX_VALUE))
        );
        panelGlass3Layout.setVerticalGroup(
            panelGlass3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelGlass3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel22)
                .addGap(83, 83, 83))
            .addGroup(panelGlass3Layout.createSequentialGroup()
                .addGap(96, 96, 96)
                .addGroup(panelGlass3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNIK1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelGlass3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNama1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelGlass3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelGlass3Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(txtAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelGlass3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTelp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(tbadd_peminjam, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabel_peminjam1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "NIK", "Nama", "Alamat", "No. HP"
            }
        ));
        tabel_peminjam1.getTableHeader().setReorderingAllowed(false);
        tabel_peminjam1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel_peminjam1MouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(tabel_peminjam1);

        btn_refresh2.setForeground(new java.awt.Color(255, 255, 255));
        btn_refresh2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/refresh.png"))); // NOI18N
        btn_refresh2.setText("Refresh");
        btn_refresh2.setRoundRect(true);
        btn_refresh2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_refresh2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Form_PeminjamLayout = new javax.swing.GroupLayout(Form_Peminjam);
        Form_Peminjam.setLayout(Form_PeminjamLayout);
        Form_PeminjamLayout.setHorizontalGroup(
            Form_PeminjamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Form_PeminjamLayout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addGroup(Form_PeminjamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Form_PeminjamLayout.createSequentialGroup()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 770, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(Form_PeminjamLayout.createSequentialGroup()
                        .addGroup(Form_PeminjamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Form_PeminjamLayout.createSequentialGroup()
                                .addComponent(panelGlass3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addGroup(Form_PeminjamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btnnext, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_refresh2, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(120, Short.MAX_VALUE))))
        );
        Form_PeminjamLayout.setVerticalGroup(
            Form_PeminjamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Form_PeminjamLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(Form_PeminjamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Form_PeminjamLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelGlass3, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Form_PeminjamLayout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addComponent(btn_refresh2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnnext, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(34, 34, 34)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 45, Short.MAX_VALUE))
        );

        jPanel2.add(Form_Peminjam, "card4");

        Data_Peminjam.setkEndColor(new java.awt.Color(0, 204, 255));
        Data_Peminjam.setkStartColor(new java.awt.Color(0, 102, 102));

        jLabel23.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("INFORMASI DATA PEMINJAM");

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Karta.png"))); // NOI18N

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("NIK");

        jLabel25.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Alamat");

        jLabel26.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Nama ");

        jLabel27.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("No telp/Hp");

        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText(":");

        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText(":");

        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText(":");

        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText(":");

        lbl_nik.setForeground(new java.awt.Color(255, 255, 255));
        lbl_nik.setText("lbl_no_ktp");

        lbl_nama.setForeground(new java.awt.Color(255, 255, 255));
        lbl_nama.setText("lbl_nama");

        lbl_alamat.setForeground(new java.awt.Color(255, 255, 255));
        lbl_alamat.setText("lbl_alamat");

        lbl_no_telp.setForeground(new java.awt.Color(255, 255, 255));
        lbl_no_telp.setText("lbl_no_telp");

        javax.swing.GroupLayout panelGlass4Layout = new javax.swing.GroupLayout(panelGlass4);
        panelGlass4.setLayout(panelGlass4Layout);
        panelGlass4Layout.setHorizontalGroup(
            panelGlass4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass4Layout.createSequentialGroup()
                .addGroup(panelGlass4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelGlass4Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(panelGlass4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelGlass4Layout.createSequentialGroup()
                                .addGap(149, 149, 149)
                                .addComponent(jLabel28))
                            .addGroup(panelGlass4Layout.createSequentialGroup()
                                .addGap(62, 62, 62)
                                .addGroup(panelGlass4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelGlass4Layout.createSequentialGroup()
                                        .addComponent(jLabel27)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(panelGlass4Layout.createSequentialGroup()
                                        .addGroup(panelGlass4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel26)
                                            .addComponent(jLabel25)
                                            .addComponent(jLabel24))
                                        .addGap(22, 22, 22)
                                        .addGroup(panelGlass4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(panelGlass4Layout.createSequentialGroup()
                                                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(panelGlass4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(lbl_no_telp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(lbl_alamat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                            .addGroup(panelGlass4Layout.createSequentialGroup()
                                                .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lbl_nik, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(panelGlass4Layout.createSequentialGroup()
                                                .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lbl_nama, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))))))))
                    .addGroup(panelGlass4Layout.createSequentialGroup()
                        .addGap(89, 89, 89)
                        .addComponent(jLabel23)))
                .addGap(0, 93, Short.MAX_VALUE))
        );
        panelGlass4Layout.setVerticalGroup(
            panelGlass4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel23)
                .addGroup(panelGlass4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelGlass4Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jLabel28)
                        .addGap(18, 18, 18)
                        .addGroup(panelGlass4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24)
                            .addComponent(jLabel32)
                            .addComponent(lbl_nik))
                        .addGap(18, 18, 18)
                        .addGroup(panelGlass4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel26)
                            .addComponent(jLabel31)
                            .addComponent(lbl_nama))
                        .addGap(18, 18, 18)
                        .addGroup(panelGlass4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(jLabel29)
                            .addComponent(lbl_alamat))
                        .addGap(41, 41, 41)
                        .addGroup(panelGlass4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel27)
                            .addComponent(jLabel30)
                            .addComponent(lbl_no_telp)))
                    .addGroup(panelGlass4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        tabel_peminjam.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "NIK", "Nama", "Alamat", "No. HP"
            }
        ));
        tabel_peminjam.getTableHeader().setReorderingAllowed(false);
        tabel_peminjam.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel_peminjamMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tabel_peminjam);

        txt_caridatapeminjam.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_caridatapeminjamKeyReleased(evt);
            }
        });

        btn_cari2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/search_lense.png"))); // NOI18N
        btn_cari2.setRoundRect(true);
        btn_cari2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cari2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelGlass8Layout = new javax.swing.GroupLayout(panelGlass8);
        panelGlass8.setLayout(panelGlass8Layout);
        panelGlass8Layout.setHorizontalGroup(
            panelGlass8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelGlass8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txt_caridatapeminjam, javax.swing.GroupLayout.PREFERRED_SIZE, 598, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_cari2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelGlass8Layout.setVerticalGroup(
            panelGlass8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btn_cari2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panelGlass8Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(txt_caridatapeminjam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout Data_PeminjamLayout = new javax.swing.GroupLayout(Data_Peminjam);
        Data_Peminjam.setLayout(Data_PeminjamLayout);
        Data_PeminjamLayout.setHorizontalGroup(
            Data_PeminjamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Data_PeminjamLayout.createSequentialGroup()
                .addGap(107, 107, 107)
                .addGroup(Data_PeminjamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 770, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(Data_PeminjamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(panelGlass8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(Data_PeminjamLayout.createSequentialGroup()
                            .addComponent(panelGlass4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, Short.MAX_VALUE))))
                .addContainerGap(268, Short.MAX_VALUE))
        );
        Data_PeminjamLayout.setVerticalGroup(
            Data_PeminjamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Data_PeminjamLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(panelGlass4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(panelGlass8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 63, Short.MAX_VALUE))
        );

        jPanel2.add(Data_Peminjam, "card6");

        Mobil.setkEndColor(new java.awt.Color(0, 204, 255));
        Mobil.setkStartColor(new java.awt.Color(0, 102, 102));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ID Mobil");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Merek");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Tahun Produksi");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Nomor Polisi");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Status Peminjaman");

        cbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tersedia", "Tidak Tersedia" }));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/car copy.png"))); // NOI18N

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Harga Sewa");

        jLabel33.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("DAFTAR MOBIL");

        javax.swing.GroupLayout panelGlass1Layout = new javax.swing.GroupLayout(panelGlass1);
        panelGlass1.setLayout(panelGlass1Layout);
        panelGlass1Layout.setHorizontalGroup(
            panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelGlass1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel33)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panelGlass1Layout.createSequentialGroup()
                        .addGroup(panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNoPol, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtYear, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelGlass1Layout.createSequentialGroup()
                        .addGroup(panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtIDMobil, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtMerek)))
                    .addGroup(panelGlass1Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelGlass1Layout.createSequentialGroup()
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtHarga, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(200, Short.MAX_VALUE))
        );
        panelGlass1Layout.setVerticalGroup(
            panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass1Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelGlass1Layout.createSequentialGroup()
                        .addGroup(panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIDMobil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtMerek, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNoPol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtHarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelGlass1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelGlass1Layout.createSequentialGroup()
                        .addComponent(jLabel33)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        btn_add.setForeground(new java.awt.Color(255, 255, 255));
        btn_add.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/plus.png"))); // NOI18N
        btn_add.setText("Add");
        btn_add.setRoundRect(true);
        btn_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_addActionPerformed(evt);
            }
        });

        btn_edit.setForeground(new java.awt.Color(255, 255, 255));
        btn_edit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/pencil_edit.png"))); // NOI18N
        btn_edit.setText("Edit");
        btn_edit.setRoundRect(true);
        btn_edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editActionPerformed(evt);
            }
        });

        btn_delete.setForeground(new java.awt.Color(255, 255, 255));
        btn_delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/trash_box.png"))); // NOI18N
        btn_delete.setText("Delete");
        btn_delete.setRoundRect(true);
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });

        tabelMobil.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabelMobil.getTableHeader().setReorderingAllowed(false);
        tabelMobil.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelMobilMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelMobil);
        if (tabelMobil.getColumnModel().getColumnCount() > 0) {
            tabelMobil.getColumnModel().getColumn(0).setResizable(false);
        }

        btn_refresh1.setForeground(new java.awt.Color(255, 255, 255));
        btn_refresh1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/refresh.png"))); // NOI18N
        btn_refresh1.setText("Refresh");
        btn_refresh1.setRoundRect(true);
        btn_refresh1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_refresh1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout MobilLayout = new javax.swing.GroupLayout(Mobil);
        Mobil.setLayout(MobilLayout);
        MobilLayout.setHorizontalGroup(
            MobilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MobilLayout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addGroup(MobilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelGlass1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(MobilLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(MobilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 874, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(MobilLayout.createSequentialGroup()
                                .addComponent(btn_add, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)
                                .addComponent(btn_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(34, 34, 34)
                                .addComponent(btn_refresh1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(213, Short.MAX_VALUE))
        );
        MobilLayout.setVerticalGroup(
            MobilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MobilLayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(panelGlass1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(MobilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btn_edit, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
                    .addComponent(btn_delete, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_refresh1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_add, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel2.add(Mobil, "card6");

        Data_Peminjaman.setkEndColor(new java.awt.Color(0, 204, 255));
        Data_Peminjaman.setkStartColor(new java.awt.Color(0, 102, 102));

        jLabel55.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(255, 255, 255));
        jLabel55.setText("INFORMASI DATA PEMINJAMAN MOBIL");

        txt_caripeminjamanmobil.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_caripeminjamanmobilKeyReleased(evt);
            }
        });

        btn_cari3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/search_lense.png"))); // NOI18N
        btn_cari3.setRoundRect(true);
        btn_cari3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cari3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelGlass12Layout = new javax.swing.GroupLayout(panelGlass12);
        panelGlass12.setLayout(panelGlass12Layout);
        panelGlass12Layout.setHorizontalGroup(
            panelGlass12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass12Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(txt_caripeminjamanmobil, javax.swing.GroupLayout.DEFAULT_SIZE, 709, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_cari3, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelGlass12Layout.setVerticalGroup(
            panelGlass12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btn_cari3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panelGlass12Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(txt_caripeminjamanmobil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        tabel_peminjaman.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ));
        tabel_peminjaman.getTableHeader().setReorderingAllowed(false);
        jScrollPane5.setViewportView(tabel_peminjaman);

        javax.swing.GroupLayout panelGlass11Layout = new javax.swing.GroupLayout(panelGlass11);
        panelGlass11.setLayout(panelGlass11Layout);
        panelGlass11Layout.setHorizontalGroup(
            panelGlass11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass11Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(panelGlass12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel56)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(panelGlass11Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 898, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelGlass11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel55)
                .addGap(120, 120, 120))
        );
        panelGlass11Layout.setVerticalGroup(
            panelGlass11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass11Layout.createSequentialGroup()
                .addGroup(panelGlass11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelGlass11Layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(jLabel56))
                    .addGroup(panelGlass11Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel55)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(panelGlass12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49))
        );

        jLabel57.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/res_car_us.png"))); // NOI18N

        javax.swing.GroupLayout Data_PeminjamanLayout = new javax.swing.GroupLayout(Data_Peminjaman);
        Data_Peminjaman.setLayout(Data_PeminjamanLayout);
        Data_PeminjamanLayout.setHorizontalGroup(
            Data_PeminjamanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Data_PeminjamanLayout.createSequentialGroup()
                .addGroup(Data_PeminjamanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Data_PeminjamanLayout.createSequentialGroup()
                        .addGap(294, 294, 294)
                        .addComponent(jLabel57))
                    .addGroup(Data_PeminjamanLayout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(panelGlass11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(138, Short.MAX_VALUE))
        );
        Data_PeminjamanLayout.setVerticalGroup(
            Data_PeminjamanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Data_PeminjamanLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(panelGlass11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel57)
                .addGap(24, 24, 24))
        );

        jPanel2.add(Data_Peminjaman, "card8");

        Form_Transaksi.setkEndColor(new java.awt.Color(0, 204, 255));
        Form_Transaksi.setkStartColor(new java.awt.Color(0, 102, 102));

        tabelTransaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "No Transaksi", "Tgl Peminjaman", "Tgl Pengembalian", "Durasi", "Total", "ID Mobil", "NIK Peminjam"
            }
        ));
        jScrollPane4.setViewportView(tabelTransaksi);

        jLabel34.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("ID Mobil              :");

        jLabel35.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("Nomor Polisi       :");

        jLabel36.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("Tahun                  :");

        jLabel37.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("Harga Sewa         :");

        lblMerek.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblMerek.setForeground(new java.awt.Color(255, 255, 255));
        lblMerek.setText("merk");

        lblTahun.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblTahun.setForeground(new java.awt.Color(255, 255, 255));
        lblTahun.setText("tahun");

        lblHarga.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblHarga.setForeground(new java.awt.Color(255, 255, 255));
        lblHarga.setText("harga");

        cbmobil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbmobilActionPerformed(evt);
            }
        });

        jLabel38.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Status                  :");

        lblStatus.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblStatus.setForeground(new java.awt.Color(255, 255, 255));
        lblStatus.setText("status");

        jLabel39.setBackground(new java.awt.Color(0, 0, 0));
        jLabel39.setFont(new java.awt.Font("Stencil", 1, 14)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(204, 255, 255));
        jLabel39.setText("MOBIL");

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("Merek                  :");

        lblnopol.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblnopol.setForeground(new java.awt.Color(255, 255, 255));
        lblnopol.setText("nopol");

        javax.swing.GroupLayout panelGlass5Layout = new javax.swing.GroupLayout(panelGlass5);
        panelGlass5.setLayout(panelGlass5Layout);
        panelGlass5Layout.setHorizontalGroup(
            panelGlass5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass5Layout.createSequentialGroup()
                .addGroup(panelGlass5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelGlass5Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(panelGlass5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(panelGlass5Layout.createSequentialGroup()
                                .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cbmobil, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelGlass5Layout.createSequentialGroup()
                                .addGroup(panelGlass5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelGlass5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel38, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel40, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(panelGlass5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lblHarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(lblMerek, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(lblTahun, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(lblStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblnopol, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                    .addGroup(panelGlass5Layout.createSequentialGroup()
                        .addGap(106, 106, 106)
                        .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        panelGlass5Layout.setVerticalGroup(
            panelGlass5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass5Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel39)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelGlass5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbmobil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelGlass5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblnopol))
                .addGap(2, 2, 2)
                .addGroup(panelGlass5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMerek)
                    .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelGlass5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTahun))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelGlass5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblHarga))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelGlass5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblStatus))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jLabel41.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("Tanggal Peminjaman     :");

        jLabel42.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("Tanggal Pengembalian  :");

        jLabel43.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("Durasi Peminjaman        :");

        jLabel44.setBackground(new java.awt.Color(0, 0, 0));
        jLabel44.setFont(new java.awt.Font("Stencil", 1, 14)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(204, 255, 255));
        jLabel44.setText("PEMINJAMAN");

        jLabel45.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 255, 255));
        jLabel45.setText("Hari");

        btn_hitung.setForeground(new java.awt.Color(255, 255, 255));
        btn_hitung.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/calculator.png"))); // NOI18N
        btn_hitung.setText("Hitung");
        btn_hitung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hitungActionPerformed(evt);
            }
        });

        jLabel46.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 255, 255));
        jLabel46.setText("TOTAL :");

        jLabel47.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setText("RP");

        txtTotal.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        txtTotal.setForeground(new java.awt.Color(0, 153, 51));
        txtTotal.setText("Total");

        javax.swing.GroupLayout panelGlass6Layout = new javax.swing.GroupLayout(panelGlass6);
        panelGlass6.setLayout(panelGlass6Layout);
        panelGlass6Layout.setHorizontalGroup(
            panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass6Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelGlass6Layout.createSequentialGroup()
                        .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelGlass6Layout.createSequentialGroup()
                                .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelGlass6Layout.createSequentialGroup()
                                        .addGap(3, 3, 3)
                                        .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel42, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(tglPengembalian, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tglPeminjaman, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(panelGlass6Layout.createSequentialGroup()
                                .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelGlass6Layout.createSequentialGroup()
                                        .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtdurasi, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(panelGlass6Layout.createSequentialGroup()
                                        .addGap(106, 106, 106)
                                        .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap(59, Short.MAX_VALUE))
                    .addGroup(panelGlass6Layout.createSequentialGroup()
                        .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(panelGlass6Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtTotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(18, 18, 18)
                        .addComponent(btn_hitung, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21))))
        );
        panelGlass6Layout.setVerticalGroup(
            panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass6Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel44)
                .addGap(18, 18, 18)
                .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tglPeminjaman, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelGlass6Layout.createSequentialGroup()
                        .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtdurasi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelGlass6Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_hitung, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33))
                            .addGroup(panelGlass6Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelGlass6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(25, Short.MAX_VALUE))))
                    .addGroup(panelGlass6Layout.createSequentialGroup()
                        .addComponent(tglPengembalian, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        lblNama.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblNama.setForeground(new java.awt.Color(255, 255, 255));
        lblNama.setText("nama");

        jLabel48.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(255, 255, 255));
        jLabel48.setText("NIK                       :");

        lblnik.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblnik.setForeground(new java.awt.Color(255, 255, 255));
        lblnik.setText("nik");

        jLabel49.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(255, 255, 255));
        jLabel49.setText("Alamat                  :");

        lblAlamat.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblAlamat.setForeground(new java.awt.Color(255, 255, 255));
        lblAlamat.setText("alamat");

        jLabel50.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(255, 255, 255));
        jLabel50.setText("No Telepon          :");

        lblTelp.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblTelp.setForeground(new java.awt.Color(255, 255, 255));
        lblTelp.setText("no telp");

        jLabel51.setBackground(new java.awt.Color(0, 0, 0));
        jLabel51.setFont(new java.awt.Font("Stencil", 1, 18)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(204, 255, 255));
        jLabel51.setText("DATA PEMINJAM");

        jLabel52.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(255, 255, 255));
        jLabel52.setText("Nama                    :");

        javax.swing.GroupLayout panelGlass9Layout = new javax.swing.GroupLayout(panelGlass9);
        panelGlass9.setLayout(panelGlass9Layout);
        panelGlass9Layout.setHorizontalGroup(
            panelGlass9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass9Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(panelGlass9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelGlass9Layout.createSequentialGroup()
                        .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblTelp, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelGlass9Layout.createSequentialGroup()
                        .addGroup(panelGlass9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel49, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                            .addComponent(jLabel48, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel52, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGroup(panelGlass9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelGlass9Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelGlass9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblNama, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblnik, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelGlass9Layout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addComponent(lblAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(33, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelGlass9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel51, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49))
        );
        panelGlass9Layout.setVerticalGroup(
            panelGlass9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelGlass9Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel51)
                .addGap(35, 35, 35)
                .addGroup(panelGlass9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNama)
                    .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelGlass9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblnik))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelGlass9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAlamat))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelGlass9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTelp))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btn_submit.setForeground(new java.awt.Color(255, 255, 255));
        btn_submit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/pinjam.png"))); // NOI18N
        btn_submit.setText("Submit");
        btn_submit.setRoundRect(true);
        btn_submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_submitActionPerformed(evt);
            }
        });

        jLabel53.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel53.setForeground(new java.awt.Color(255, 255, 255));
        jLabel53.setText("TRANSAKSI PEMINJAMAN MOBIL");

        javax.swing.GroupLayout Form_TransaksiLayout = new javax.swing.GroupLayout(Form_Transaksi);
        Form_Transaksi.setLayout(Form_TransaksiLayout);
        Form_TransaksiLayout.setHorizontalGroup(
            Form_TransaksiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Form_TransaksiLayout.createSequentialGroup()
                .addGroup(Form_TransaksiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Form_TransaksiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Form_TransaksiLayout.createSequentialGroup()
                            .addGap(64, 64, 64)
                            .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(Form_TransaksiLayout.createSequentialGroup()
                            .addGap(24, 24, 24)
                            .addComponent(panelGlass9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(panelGlass5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(panelGlass6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(Form_TransaksiLayout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_submit, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(177, Short.MAX_VALUE))
        );
        Form_TransaksiLayout.setVerticalGroup(
            Form_TransaksiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Form_TransaksiLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(Form_TransaksiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelGlass6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(Form_TransaksiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(panelGlass9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(panelGlass5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(Form_TransaksiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Form_TransaksiLayout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Form_TransaksiLayout.createSequentialGroup()
                        .addGap(88, 88, 88)
                        .addComponent(btn_submit, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(68, Short.MAX_VALUE))
        );

        jPanel2.add(Form_Transaksi, "card8");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tbAddStaffMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbAddStaffMouseClicked

    }//GEN-LAST:event_tbAddStaffMouseClicked

    private void tbAddStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbAddStaffActionPerformed
        jPanel2.removeAll();
        jPanel2.repaint();
        jPanel2.revalidate();
        
        jPanel2.add(Pegawai);
        jPanel2.repaint();
        jPanel2.revalidate();
        
    }//GEN-LAST:event_tbAddStaffActionPerformed

    private void tbAddMobilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbAddMobilActionPerformed
        jPanel2.removeAll();
        jPanel2.repaint();
        jPanel2.revalidate();
        
        jPanel2.add(Mobil);
        jPanel2.repaint();
        jPanel2.revalidate();
        
    }//GEN-LAST:event_tbAddMobilActionPerformed

    private void tbAddPeminjamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbAddPeminjamMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tbAddPeminjamMouseClicked

    private void tbAddPeminjamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbAddPeminjamActionPerformed
        jPanel2.removeAll();
        jPanel2.repaint();
        jPanel2.revalidate();
        
        jPanel2.add(Form_Peminjam);
        jPanel2.repaint();
        jPanel2.revalidate(); 
        
    }//GEN-LAST:event_tbAddPeminjamActionPerformed

    private void tbDataPeminjamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbDataPeminjamMouseClicked

    }//GEN-LAST:event_tbDataPeminjamMouseClicked

    private void tbDataPeminjamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbDataPeminjamActionPerformed
        jPanel2.removeAll();
        jPanel2.repaint();
        jPanel2.revalidate();
        
        jPanel2.add(Data_Peminjam);
        jPanel2.repaint();
        jPanel2.revalidate(); 
    }//GEN-LAST:event_tbDataPeminjamActionPerformed

    private void tbDataPeminjamanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbDataPeminjamanActionPerformed
        jPanel2.removeAll();
        jPanel2.repaint();
        jPanel2.revalidate();
        
        jPanel2.add(Data_Peminjaman);
        jPanel2.repaint();
        jPanel2.revalidate(); 
    }//GEN-LAST:event_tbDataPeminjamanActionPerformed
 
    
    private void btn_edit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_edit1ActionPerformed
        User user = new User();

        user.NIK = txtNIK.getText();
        user.Nama = txtNama.getText();
        user.Username = txtUser.getText();
        user.Password = txtPass.getText();
        user.Role = (String) cbRole.getSelectedItem();

        if (user.NIK.isEmpty() || user.Nama.isEmpty() || user.Username.isEmpty() || user.Password.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Semua kolom input harus diisi.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        } else if (!isValidName(user.Nama)) {
            JOptionPane.showMessageDialog(null, "Nama hanya boleh mengandung huruf.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        } else {
            try {
                if (user.editUser()) {
                    JOptionPane.showMessageDialog(null, "Data Berhasil Diubah", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("Data berhasil Diubah");
                    display_user();
                } else {
                    JOptionPane.showMessageDialog(null, "Gagal mengubah data", "Kesalahan", JOptionPane.ERROR_MESSAGE);
                    System.out.println("Gagal mengubah data");
                }
            } catch (HeadlessException e) {
                JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage(), "Kesalahan Umum", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

// Fungsi untuk memeriksa apakah Nama hanya mengandung huruf
    private boolean isValidName(String name) {
        return name.matches("^[a-zA-Z\\s]+$");
  
    }//GEN-LAST:event_btn_edit1ActionPerformed

    private void cari_peminjamMobil() {
        Transaksi transaksi = new Transaksi();
        
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No Transaksi");
        model.addColumn("Tgl Peminjaman");
        model.addColumn("Tgl Pengembalian");
        model.addColumn("Durasi");
        model.addColumn("Total");
        model.addColumn("ID Mobil");
        model.addColumn("NIK Peminjam");
        String cari = txt_caripeminjamanmobil.getText();
        try {
            String sql = "SELECT * FROM transaksimobil WHERE No_Transaksi LIKE ? OR Total LIKE ? OR Mobil_ID_Mobil LIKE ? OR Peminjam_NIK LIKE ?";
            java.sql.Connection conn = (Connection) Database.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, "%" + cari + "%"); 
            pst.setString(2, "%" + cari + "%"); 
            pst.setString(3, "%" + cari + "%"); 
            pst.setString(4, "%" + cari + "%");
            java.sql.ResultSet res = pst.executeQuery();

            while (res.next()) {
                model.addRow(new Object[]{ 
                    res.getString(1), 
                    res.getString(2), 
                    res.getString(3), 
                    res.getString(4),
                    res.getString(5),
                    res.getString(6),
                    res.getString(7)});
            }
            tabel_peminjaman.setModel(model);
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }    
    
    private void cari_peminjam() {
        Peminjam p = new Peminjam();
        
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("NIK");
        model.addColumn("Nama");
        model.addColumn("Alamat");
        model.addColumn("No Telp");
        String cari = txt_caridatapeminjam.getText();
        try {
            String sql = "SELECT * FROM peminjam WHERE NIK LIKE ? OR Nama LIKE ? OR Alamat LIKE ? OR No_Telp LIKE ?";
            java.sql.Connection conn = (Connection) Database.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, "%" + cari + "%");
            pst.setString(2, "%" + cari + "%");
            pst.setString(3, "%" + cari + "%");
            pst.setString(4, "%" + cari + "%");
            java.sql.ResultSet res = pst.executeQuery();

            while (res.next()) {
                model.addRow(new Object[]{ 
                    res.getString(1), 
                    res.getString(2), 
                    res.getString(3), 
                    res.getString(4)});
            }
            tabel_peminjam.setModel(model);
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }    
    
    private void cari_user() {
        User user = new User();
        
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Nama");
        model.addColumn("Username");
        model.addColumn("Role");
        String cari = txt_cari.getText();
        try {
            String sql = "SELECT * FROM user WHERE NIK LIKE ? OR Nama LIKE ? OR Username LIKE ?";
            java.sql.Connection conn = (Connection) Database.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, "%" + cari + "%"); // Mencari NIK yang mengandung teks cari
            pst.setString(2, "%" + cari + "%"); // Mencari Nama yang mengandung teks cari
            pst.setString(3, "%" + cari + "%"); // Mencari Username yang mengandung teks cari
            java.sql.ResultSet res = pst.executeQuery();

            while (res.next()) {
                model.addRow(new Object[]{ 
                    res.getString(1), 
                    res.getString(2), 
                    res.getString(3)});
            }
            tabelPegawai.setModel(model);
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    
    private void btn_delete1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_delete1ActionPerformed
        String inputNIK = txtNIK.getText().trim(); // Menghapus spasi ekstra dan menghindari NIK kosong

        if (inputNIK.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Silakan pilih atau masukkan NIK terlebih dahulu.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        } else {
            int option = JOptionPane.showConfirmDialog(null, "Apakah Anda yakin ingin menghapus data pengguna dengan NIK " + inputNIK + "?", "Konfirmasi Hapus Data", JOptionPane.YES_NO_OPTION);

            if (option == JOptionPane.YES_OPTION) {
                User user = new User();
                user.NIK = inputNIK;

                try {
                    if (user.deleteUser()) {
                        JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                        System.out.println("Data berhasil Dihapus");
                        display_user();
                    } else {
                        JOptionPane.showMessageDialog(null, "Gagal menghapus data", "Kesalahan", JOptionPane.ERROR_MESSAGE);
                        System.out.println("Gagal menghapus data");
                    }
                } catch (HeadlessException e) {
                    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage(), "Kesalahan Umum", JOptionPane.ERROR_MESSAGE);
                }
            }
        }


    }//GEN-LAST:event_btn_delete1ActionPerformed

    
    
    private void tabelPegawaiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelPegawaiMouseClicked
        // TODO add your handling code here:
        int baris = tabelPegawai.rowAtPoint(evt.getPoint());
        String nik = tabelPegawai.getValueAt(baris, 0).toString();
        txtNIK.setText(nik);

        String nama = tabelPegawai.getValueAt(baris, 1).toString();
        txtNama.setText(nama);

        String username = tabelPegawai.getValueAt(baris,2).toString();
        txtUser.setText(username);

        String pass = tabelPegawai.getValueAt(baris, 3).toString();
        txtPass.setText(pass);

        String jb = tabelPegawai.getValueAt(baris, 4).toString();
        cbRole.setSelectedItem(jb);

    }//GEN-LAST:event_tabelPegawaiMouseClicked

    private void btn_cari1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cari1ActionPerformed

    }//GEN-LAST:event_btn_cari1ActionPerformed

    private void btnnextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnextActionPerformed
                 
    // Validasi data input
        String nama = txtNama1.getText();
        String nik = txtNIK1.getText();
        String alamat = txtAlamat.getText();
        String telp = txtTelp.getText();
    
        lblNama.setText(nama);
        lblnik.setText(nik);
        lblAlamat.setText(alamat);
        lblTelp.setText(telp);

        if (nama.isEmpty() || nik.isEmpty() || alamat.isEmpty() || telp.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Data isian ada yang kosong");
        } else {
            jPanel2.removeAll();
            jPanel2.repaint();
            jPanel2.revalidate();

            display_transaksi();
            loadMobil();

            jPanel2.add(Form_Transaksi);
            jPanel2.repaint();
            jPanel2.revalidate(); 

        }
    }//GEN-LAST:event_btnnextActionPerformed

    
    private void createPeminjam() {
        Peminjam peminjam = new Peminjam();

        String Nama = txtNama1.getText().trim();
        String NIKText = txtNIK1.getText().trim();
        String Alamat = txtAlamat.getText().trim();
        String No_Telp = txtTelp.getText().trim();

        if (Nama.isEmpty() || NIKText.isEmpty() || Alamat.isEmpty() || No_Telp.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua kolom input harus diisi.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        } else {
            if (NIKText.matches("^\\d{5}$")) { // Memastikan NIK hanya berisi 5 angka
                if (Nama.matches("^[A-Za-z\\s]+$")) { // Memastikan Nama hanya berisi huruf
                    try {
                        int NIK = Integer.parseInt(NIKText);
                        peminjam.Nama = Nama;
                        peminjam.NIK = NIK;
                        peminjam.Alamat = Alamat;
                        peminjam.No_Telp = No_Telp;

                        try {
                            if (peminjam.createPeminjam()) {
                                JOptionPane.showMessageDialog(null, "Data Berhasil Ditambahkan", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                                System.out.println("Data Peminjam berhasil Ditambahkan");
                                display_peminjam();
                            } else {
                                JOptionPane.showMessageDialog(null, "Data Peminjam Sudah Ada", "Error", JOptionPane.ERROR_MESSAGE);
                                System.out.println("Gagal Menambahkan Peminjam");
                            }
                        } catch (HeadlessException e) {
                            JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage(), "Kesalahan Umum", JOptionPane.ERROR_MESSAGE);
                        }
                        // Tangani kesalahan SQL (database) jika terjadi

                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "NIK Tidak Valid", "Kesalahan", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Nama hanya boleh berisi huruf.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "NIK harus terdiri dari 5 angka.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void tbadd_peminjamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbadd_peminjamActionPerformed
        createPeminjam();
    
    }//GEN-LAST:event_tbadd_peminjamActionPerformed

    private void tabel_peminjamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabel_peminjamMouseClicked

        lbl_nik.setText(String.valueOf(tabel_peminjam.getValueAt(tabel_peminjam.getSelectedRow(),0)));
        lbl_nama.setText(String.valueOf( tabel_peminjam.getValueAt(tabel_peminjam.getSelectedRow(),1)));
        lbl_alamat.setText(String.valueOf(tabel_peminjam.getValueAt(tabel_peminjam.getSelectedRow(),2)));
        lbl_no_telp.setText(String.valueOf( tabel_peminjam.getValueAt(tabel_peminjam.getSelectedRow(),3)));
    }//GEN-LAST:event_tabel_peminjamMouseClicked

    
    private void btn_cari2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cari2ActionPerformed

    }//GEN-LAST:event_btn_cari2ActionPerformed

    private void btn_add1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_add1ActionPerformed
        String NIK = txtNIK.getText().trim();
        String Nama = txtNama.getText().trim();
        String Username = txtUser.getText().trim();
        String Password = txtPass.getText();
        String Role = cbRole.getSelectedItem().toString();

        if (NIK.isEmpty() || Nama.isEmpty() || Username.isEmpty() || Password.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Semua kolom input harus diisi.", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (!NIK.matches("\\d{5}")) {
            JOptionPane.showMessageDialog(null, "NIK harus terdiri dari 5 angka.", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (!Nama.matches("^[A-Za-z\\s]+$")) {
            JOptionPane.showMessageDialog(null, "Nama harus berisi huruf", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            User user = new User();
            user.NIK = NIK;
            user.Nama = Nama;
            user.Username = Username;
            user.Password = Password;
            user.Role = Role;

            try {
                if (user.createUser()) {
                    JOptionPane.showMessageDialog(null, "Data Berhasil Ditambahkan", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("User berhasil Ditambahkan");
                    display_user();
                } else {
                    JOptionPane.showMessageDialog(null, "Gagal menambahkan Data User. Cek kembali input Anda.", "Error", JOptionPane.ERROR_MESSAGE);
                    System.out.println("Gagal Menambahkan User");
                }
            } catch (HeadlessException e) {
                JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage(), "Kesalahan Umum", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_btn_add1ActionPerformed

    private void btn_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_addActionPerformed
        String ID_Mobil = txtIDMobil.getText().trim();
        String Merek = txtMerek.getText().trim();
        String Tahun_Produksi = txtYear.getText().trim();
        String Nomor_Polisi = txtNoPol.getText().trim();
        String hargaText = txtHarga.getText().trim();
        String Status = (String) cbStatus.getSelectedItem();

        if (ID_Mobil.isEmpty() || Merek.isEmpty() || Tahun_Produksi.isEmpty() || Nomor_Polisi.isEmpty() || hargaText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua kolom input harus diisi.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        } else if (ID_Mobil.length() != 4 || !ID_Mobil.startsWith("M") || !ID_Mobil.substring(1).matches("\\d{3}")) {
            JOptionPane.showMessageDialog(this, "ID Mobil harus terdiri dari 4 karakter dengan format yang benar (MXXX), di mana XXX adalah tiga digit angka.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        } else {
            try {
                Mobil mobil = new Mobil();
                int harga = Integer.parseInt(hargaText);
                mobil.ID_Mobil = ID_Mobil;
                mobil.Merek = Merek;
                mobil.Tahun_Produksi = Tahun_Produksi;
                mobil.Nomor_Polisi = Nomor_Polisi;
                mobil.Harga_Sewa = harga;
                mobil.Status = Status;

                if (mobil.createMobil()) {
                    JOptionPane.showMessageDialog(this, "Data Berhasil Ditambahkan", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                    clear_mobil();
                } else {
                    JOptionPane.showMessageDialog(this, "Gagal menambahkan data mobil. Silakan cek kembali input Anda.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Harga harus berupa angka.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        }
        display_mobil();
        clear_mobil();
    }//GEN-LAST:event_btn_addActionPerformed

    private void btn_editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editActionPerformed
        Mobil mobil = new Mobil();

        String ID_Mobil = txtIDMobil.getText().trim();
        String Merek = txtMerek.getText().trim();
        String Tahun_Produksi = txtYear.getText().trim();
        String Nomor_Polisi = txtNoPol.getText().trim();
        String hargaText = txtHarga.getText().trim();
        String Status = (String) cbStatus.getSelectedItem();
            if (ID_Mobil.isEmpty() || Merek.isEmpty() || Tahun_Produksi.isEmpty() || Nomor_Polisi.isEmpty() || hargaText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Semua kolom input harus diisi.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
            } else if (ID_Mobil.length() != 4 || !ID_Mobil.startsWith("M") || !ID_Mobil.substring(1).matches("\\d{3}")) {
                JOptionPane.showMessageDialog(this, "ID Mobil harus terdiri dari 4 karakter dengan format yang benar (MXXX), XXX adalah tiga digit angka.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
            } else if (!Merek.matches("[a-zA-Z]+")) {
                JOptionPane.showMessageDialog(this, "Merek harus berupa huruf.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
            } else {
                try {
                    int harga = Integer.parseInt(hargaText);
                    mobil.ID_Mobil = ID_Mobil;
                    mobil.Merek = Merek;
                    mobil.Tahun_Produksi = Tahun_Produksi;
                    mobil.Nomor_Polisi = Nomor_Polisi;
                    mobil.Harga_Sewa = harga;
                    mobil.Status = Status;

                    if (mobil.updateMobil()) {
                        JOptionPane.showMessageDialog(this, "Data Berhasil Diubah", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                        clear_mobil();
                    } else {
                        JOptionPane.showMessageDialog(this, "Gagal mengubah data mobil. Silakan cek kembali input Anda.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Harga harus berupa angka.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
                }
            }
    }//GEN-LAST:event_btn_editActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
        String inputIDMobil = txtIDMobil.getText().trim(); // Menghapus spasi ekstra dan menghindari ID Mobil kosong

        if (inputIDMobil.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Masukkan ID Mobil terlebih dahulu.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        } else {
            int option = JOptionPane.showConfirmDialog(null, "Apakah Anda yakin ingin menghapus data mobil dengan ID " + inputIDMobil + "?", "Konfirmasi Hapus Data", JOptionPane.YES_NO_OPTION);

            if (option == JOptionPane.YES_OPTION) {
                Mobil mobil = new Mobil();
                mobil.ID_Mobil = inputIDMobil;

                try {
                    if (mobil.deleteMobil()) {
                        JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                        System.out.println("Data berhasil Dihapus");
                        display_mobil();
                    } else {
                        JOptionPane.showMessageDialog(null, "Gagal menghapus data", "Kesalahan", JOptionPane.ERROR_MESSAGE);
                        System.out.println("Gagal menghapus data");
                    }
                } catch (HeadlessException e) {
                    JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage(), "Kesalahan Umum", JOptionPane.ERROR_MESSAGE);
                }
            }
        
        }
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void tabelMobilMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelMobilMouseClicked
        int baris = tabelMobil.rowAtPoint(evt.getPoint());
        String Id = tabelMobil.getValueAt(baris, 0).toString();
        txtIDMobil.setText(Id);

        String merk = tabelMobil.getValueAt(baris, 1).toString();
        txtMerek.setText(merk);

        String produksi = tabelMobil.getValueAt(baris,2).toString();
        txtYear.setText(produksi);

        String nopol = tabelMobil.getValueAt(baris, 3).toString();
        txtNoPol.setText(nopol);

        String hrga = tabelMobil.getValueAt(baris, 4).toString();
        txtHarga.setText(hrga);

        String status = tabelMobil.getValueAt(baris, 5).toString();
        cbStatus.setSelectedItem(status);
    }//GEN-LAST:event_tabelMobilMouseClicked
  
    
    
    private void hitungtotal(){
        try {
            SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
            String strDate1 = df.format(tglPeminjaman.getDate());
            String strDate2 = df.format(tglPengembalian.getDate());
            Date Tanggal1 = df.parse(strDate1);
            Date Tanggal2 = df.parse(strDate2);

            if (Tanggal2.before(Tanggal1)) {
                JOptionPane.showMessageDialog(this, "Input Tanggal Pengembalian Dengan Benar", "Kesalahan", JOptionPane.ERROR_MESSAGE);
            } else {
                long Hari1 = Tanggal1.getTime();
                long Hari2 = Tanggal2.getTime();
                long selisih = Hari2 - Hari1;
                long durasi = selisih / (24 * 60 * 60 * 1000);
                String Hasil = (Long.toString(durasi));
                txtdurasi.setText(Hasil);

                int harga_sewa = Integer.parseInt(lblHarga.getText()); // lbHarga di pars ke integer
                int durasi_sewa = Integer.parseInt(txtdurasi.getText());   // txtdurasi di pars ke integer
                int Total = harga_sewa * durasi_sewa;                     // mencari total Harga
                String a = Integer.toString(Total);
                txtTotal.setText(a);
            }
        } catch (NumberFormatException | ParseException e) {
            JOptionPane.showMessageDialog(this, "Masukan Tanggal Peminjaman dan Tanggal Pengembalian");
        }
    }
    
    private void btn_cari3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cari3ActionPerformed

    }//GEN-LAST:event_btn_cari3ActionPerformed

    private void txt_caripeminjamanmobilKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_caripeminjamanmobilKeyReleased
        cari_peminjamMobil();
    }//GEN-LAST:event_txt_caripeminjamanmobilKeyReleased

    private void btn_refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_refreshActionPerformed
        loadTabelUser();
    }//GEN-LAST:event_btn_refreshActionPerformed

    private void btn_refresh1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_refresh1ActionPerformed
        loadTabelMobil();
    }//GEN-LAST:event_btn_refresh1ActionPerformed

    private void tabel_peminjam1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabel_peminjam1MouseClicked
        int baris = tabel_peminjam1.rowAtPoint(evt.getPoint());
        String nik = tabel_peminjam1.getValueAt(baris, 0).toString();
        txtNIK1.setText(nik);

        String nama = tabel_peminjam1.getValueAt(baris, 1).toString();
        txtNama1.setText(nama);

        String alamat = tabel_peminjam1.getValueAt(baris,2).toString();
        txtAlamat.setText(alamat);

        String telp = tabel_peminjam1.getValueAt(baris, 3).toString();
        txtTelp.setText(telp);
    }//GEN-LAST:event_tabel_peminjam1MouseClicked

    private void cbmobilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbmobilActionPerformed

        // Dapatkan nilai yang dipilih dari combo box
        String selectedNopol = (String) cbmobil.getSelectedItem();

        // Membuat koneksi dan pernyataan SQL
        try (java.sql.Connection conn = (Connection)Database.configDB();
            java.sql.PreparedStatement pstmt = conn.prepareStatement("SELECT Merek, Tahun_Produksi, Nomor_Polisi, Harga_Sewa, Status FROM mobil WHERE ID_Mobil = ?")) {

            // Set parameter untuk query SQL
            pstmt.setString(1, selectedNopol);

            // Eksekusi query
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    // Isi label-label dengan data dari database
                    lblMerek.setText(rs.getString("Merek"));
                    lblTahun.setText(rs.getString("Tahun_Produksi"));
                    lblnopol.setText(rs.getString("Nomor_Polisi"));
                    lblHarga.setText(rs.getString("Harga_Sewa"));
                    lblStatus.setText(rs.getString("Status"));
                }
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Menu_Owner.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_cbmobilActionPerformed

    private void btn_hitungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hitungActionPerformed
        hitungtotal();
    }//GEN-LAST:event_btn_hitungActionPerformed
 
    public void display_transaksi() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No Transaksi");
        model.addColumn("Tgl Peminjaman");
        model.addColumn("Tgl Pengembalian");
        model.addColumn("Durasi");
        model.addColumn("Total");
        model.addColumn("ID Mobil");
        model.addColumn("NIK Peminjam");
        
        try {
            String sql = "SELECT * FROM transaksimobil";
            java.sql.Connection conn = (Connection)Database.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
  

            model.setRowCount(0); // Kosongkan tabel sebelum mengisi data baru

            while(res.next()){
                String[] row = new String[7];
                row[0] = res.getString(1);
                row[1] = res.getString(2);
                row[2] = res.getString(3);
                row[3] = res.getString(4);
                row[4] = res.getString(5);
                row[5] = res.getString(6);
                row[6] = res.getString(7);

                model.addRow(row);
                
            }tabelTransaksi.setModel(model);
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Menu_Owner.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }
    
    public void cekstatus() throws SQLException {
        String nopolValue = cbmobil.getSelectedItem().toString();
        String status1 = "";

        // Memeriksa status mobil
        String selectSql = "SELECT Status FROM mobil WHERE ID_Mobil = ?";
        try (java.sql.Connection conn = (Connection)Database.configDB();
             java.sql.PreparedStatement selectPstmt = conn.prepareStatement(selectSql)) {
            selectPstmt.setString(1, nopolValue);
            ResultSet rs = selectPstmt.executeQuery();

            while (rs.next()) {
                status1 = rs.getString("Status");
            }

            if (!status1.equals("Tidak Tersedia")) {
                // Mengubah status mobil menjadi "Tidak Tersedia"
                String updateSql = "UPDATE mobil SET Status = 'Tidak Tersedia' WHERE ID_Mobil = ?";
                try (java.sql.PreparedStatement updatePstmt = conn.prepareStatement(updateSql)) {
                    updatePstmt.setString(1, nopolValue);
                    int rowsAffected = updatePstmt.executeUpdate();

                    if (rowsAffected > 0) {
                        System.out.println("Status mobil berhasil diubah menjadi 'Tidak Tersedia'");
                        System.out.println(updateSql);
                    }
                }
            }
        }
    }    
    
    public boolean mobil_tidaktersedia() throws SQLException {
        boolean hasil;
        String nopolValue = cbmobil.getSelectedItem().toString();
        String status1 = "";

        // Memeriksa status mobil
        String sql = "SELECT Status FROM mobil WHERE ID_Mobil = ?";
        try (java.sql.Connection conn = (Connection)Database.configDB();
             java.sql.PreparedStatement selectPstmt = conn.prepareStatement(sql)) {
            selectPstmt.setString(1, nopolValue);
            ResultSet rs = selectPstmt.executeQuery();

            while (rs.next()) {
                status1 = rs.getString("Status");
            }

            hasil = !status1.equals("Tidak Tersedia");
            return hasil;
        
        }
    }
    
    private void create_peminjaman() {
        Transaksi transaksi = new Transaksi();
        try {
            if (!lblNama.getText().isEmpty()) {
                if (tglPeminjaman.getDate() != null && tglPengembalian.getDate() != null) {
                    if (!mobil_tidaktersedia()) {
                        JOptionPane.showMessageDialog(this, "Maaf mobil ini sedang tidak tersedia");
                    } else {
                        java.util.Date tgl = (java.util.Date) this.tglPeminjaman.getDate();
                        java.util.Date tgl1 = (java.util.Date) this.tglPengembalian.getDate();
                        String durasi = txtdurasi.getText();
                        String total = txtTotal.getText();
                        String idmobil = cbmobil.getSelectedItem().toString();
                        String nik_peminjam = lblnik.getText();

                        if (durasi.isEmpty()) {
                            JOptionPane.showMessageDialog(this, "Harap Tekan Tombol Hitung Sebelum Submit", "Pesan Kesalahan", JOptionPane.INFORMATION_MESSAGE);
                        }
                         else {
                            // Simpan data transaksi ke tabel tb_transaksi
                            String sql = "INSERT INTO transaksimobil (`Tgl_Peminjaman`, `Tgl_Pengembalian`, `Durasi`, `Total`, `Mobil_ID_Mobil`, `Peminjam_NIK`) VALUES (?, ?, ?, ?, ?, ?)";
                            java.sql.Connection conn = (Connection) Database.configDB();
                            java.sql.PreparedStatement pstm = conn.prepareStatement(sql);
                            pstm.setDate(1, new java.sql.Date(tgl.getTime()));
                            pstm.setDate(2, new java.sql.Date(tgl1.getTime()));
                            pstm.setString(3, durasi);
                            pstm.setString(4, total);
                            pstm.setString(5, idmobil);
                            pstm.setString(6, nik_peminjam);

                            int rowsAffectedTransaksi = pstm.executeUpdate();

                            if (rowsAffectedTransaksi > 0) {                        
                                cekstatus(); 
                                JOptionPane.showMessageDialog(this, "Data Transaksi Berhasil Disimpan");
                            } else {
                                JOptionPane.showMessageDialog(this, "Gagal menyimpan data transaksi");
                            }
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Tanggal Peminjaman dan Tanggal Pengembalian harus diisi");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Data isian ada yang kosong");
            }
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(this, "Error input data: " + e.getMessage());
        }
        display_transaksi();
        clearTransaksi();
    }  
    
    private void clearTransaksi() {
        txtTotal.setText("");
        txtdurasi.setText("");
    } 
    
    public void loadMobil() {  
        try {
            String sql = "SELECT ID_Mobil FROM mobil";
            java.sql.Connection conn = (Connection)Database.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
            while (res.next()) {
                cbmobil.addItem(res.getString("ID_Mobil"));

            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Menu_Owner.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    
    }

    
    private void btn_submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_submitActionPerformed
        create_peminjaman();
    }//GEN-LAST:event_btn_submitActionPerformed

    private void cbRoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbRoleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbRoleActionPerformed

    private void btn_logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logoutActionPerformed

        int choice = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin keluar dari program?", "Konfirmasi Keluar", JOptionPane.YES_NO_OPTION);

        if (choice == JOptionPane.YES_OPTION) {
            System.out.println("Keluar Dari Program");
            System.exit(0);
        }
    }//GEN-LAST:event_btn_logoutActionPerformed

    private void btn_refresh2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_refresh2ActionPerformed
        clear_peminjam();
    }//GEN-LAST:event_btn_refresh2ActionPerformed

    private void txt_cariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_cariKeyReleased
        cari_user();
    }//GEN-LAST:event_txt_cariKeyReleased

    private void txt_caridatapeminjamKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_caridatapeminjamKeyReleased
        cari_peminjam();
    }//GEN-LAST:event_txt_caridatapeminjamKeyReleased

    public void loadTabelMobil(){
        Database konek = new Database();
        
        konek.openConnection();
        
        ArrayList<ArrayList> mobil = konek.all("SELECT * FROM mobil");
       
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID Mobil");
        model.addColumn("Merek");
        model.addColumn("Tahun Produksi");
        model.addColumn("No Polisi");
        model.addColumn("Harga Sewa");
        model.addColumn("Status");
        
        for (ArrayList<String> rowData : mobil) {
            model.addRow(rowData.toArray());
        }
        
        konek.closeConnection();
        tabelMobil.setModel(model);
        clear_mobil();
    }
    
    private void loadTabelUser(){
        Database konek = new Database();
        
        konek.openConnection();
        
        ArrayList<ArrayList> user = konek.all("SELECT * FROM user");
       
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("NIK");
        model.addColumn("Nama");
        model.addColumn("Username");
        model.addColumn("Password");
        model.addColumn("Role");
        
        for (ArrayList<String> rowData : user) {
            model.addRow(rowData.toArray());
        }
        
        konek.closeConnection();
        tabelPegawai.setModel(model);
        clear_user();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu_Owner.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Menu_Owner().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private keeptoo.KGradientPanel Dashboard;
    private keeptoo.KGradientPanel Data_Peminjam;
    private keeptoo.KGradientPanel Data_Peminjaman;
    private keeptoo.KGradientPanel Form_Peminjam;
    private keeptoo.KGradientPanel Form_Transaksi;
    private keeptoo.KGradientPanel Mobil;
    private keeptoo.KGradientPanel Pegawai;
    private usu.widget.ButtonGlass btn_add;
    private usu.widget.ButtonGlass btn_add1;
    private usu.widget.ButtonGlass btn_cari1;
    private usu.widget.ButtonGlass btn_cari2;
    private usu.widget.ButtonGlass btn_cari3;
    private usu.widget.ButtonGlass btn_delete;
    private usu.widget.ButtonGlass btn_delete1;
    private usu.widget.ButtonGlass btn_edit;
    private usu.widget.ButtonGlass btn_edit1;
    private usu.widget.ButtonGlass btn_hitung;
    private usu.widget.ButtonGlass btn_logout;
    private usu.widget.ButtonGlass btn_refresh;
    private usu.widget.ButtonGlass btn_refresh1;
    private usu.widget.ButtonGlass btn_refresh2;
    private usu.widget.ButtonGlass btn_submit;
    private usu.widget.ButtonGlass btnnext;
    private javax.swing.JComboBox<String> cbRole;
    private javax.swing.JComboBox<String> cbStatus;
    private javax.swing.JComboBox<String> cbmobil;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private keeptoo.KGradientPanel kGradientPanel1;
    private javax.swing.JLabel lblAlamat;
    private javax.swing.JLabel lblHarga;
    private javax.swing.JLabel lblMerek;
    private javax.swing.JLabel lblNama;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblTahun;
    private javax.swing.JLabel lblTelp;
    private javax.swing.JLabel lbl_alamat;
    private javax.swing.JLabel lbl_nama;
    private javax.swing.JLabel lbl_nik;
    private javax.swing.JLabel lbl_no_telp;
    private javax.swing.JLabel lblnik;
    private javax.swing.JLabel lblnopol;
    private usu.widget.glass.PanelGlass panelGlass1;
    private usu.widget.glass.PanelGlass panelGlass11;
    private usu.widget.glass.PanelGlass panelGlass12;
    private usu.widget.glass.PanelGlass panelGlass2;
    private usu.widget.glass.PanelGlass panelGlass3;
    private usu.widget.glass.PanelGlass panelGlass4;
    private usu.widget.glass.PanelGlass panelGlass5;
    private usu.widget.glass.PanelGlass panelGlass6;
    private usu.widget.glass.PanelGlass panelGlass7;
    private usu.widget.glass.PanelGlass panelGlass8;
    private usu.widget.glass.PanelGlass panelGlass9;
    private javax.swing.JTable tabelMobil;
    private javax.swing.JTable tabelPegawai;
    private javax.swing.JTable tabelTransaksi;
    private javax.swing.JTable tabel_peminjam;
    private javax.swing.JTable tabel_peminjam1;
    private javax.swing.JTable tabel_peminjaman;
    private usu.widget.ButtonGlass tbAddMobil;
    private usu.widget.ButtonGlass tbAddPeminjam;
    private usu.widget.ButtonGlass tbAddStaff;
    private usu.widget.ButtonGlass tbDataPeminjam;
    private usu.widget.ButtonGlass tbDataPeminjaman;
    private javax.swing.JButton tbadd_peminjam;
    private com.toedter.calendar.JDateChooser tglPeminjaman;
    private com.toedter.calendar.JDateChooser tglPengembalian;
    private javax.swing.JTextField txtAlamat;
    private javax.swing.JTextField txtHarga;
    private javax.swing.JTextField txtIDMobil;
    private javax.swing.JTextField txtMerek;
    private javax.swing.JTextField txtNIK;
    private javax.swing.JTextField txtNIK1;
    private javax.swing.JTextField txtNama;
    private javax.swing.JTextField txtNama1;
    private javax.swing.JTextField txtNoPol;
    private javax.swing.JPasswordField txtPass;
    private javax.swing.JTextField txtTelp;
    private javax.swing.JLabel txtTotal;
    private javax.swing.JTextField txtUser;
    private javax.swing.JTextField txtYear;
    private javax.swing.JTextField txt_cari;
    private javax.swing.JTextField txt_caridatapeminjam;
    private javax.swing.JTextField txt_caripeminjamanmobil;
    private javax.swing.JTextField txtdurasi;
    // End of variables declaration//GEN-END:variables
}
